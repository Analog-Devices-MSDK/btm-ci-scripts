#! /usr/bin/env python3

################################################################################
 # Copyright (C) 2020 Maxim Integrated Products, Inc., All Rights Reserved.
 #
 # Permission is hereby granted, free of charge, to any person obtaining a
 # copy of this software and associated documentation files (the "Software"),
 # to deal in the Software without restriction, including without limitation
 # the rights to use, copy, modify, merge, publish, distribute, sublicense,
 # and/or sell copies of the Software, and to permit persons to whom the
 # Software is furnished to do so, subject to the following conditions:
 #
 # The above copyright notice and this permission notice shall be included
 # in all copies or substantial portions of the Software.
 #
 # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 # OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 # MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 # IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 # OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 # OTHER DEALINGS IN THE SOFTWARE.
 #
 # Except as contained in this notice, the name of Maxim Integrated
 # Products, Inc. shall not be used except as stated in the Maxim Integrated
 # Products, Inc. Branding Policy.
 #
 # The mere transfer of this software does not imply any licenses
 # of trade secrets, proprietary technology, copyrights, patents,
 # trademarks, maskwork rights, or any other form of intellectual
 # property whatsoever. Maxim Integrated Products, Inc. retains all
 # ownership rights.
 #
 ###############################################################################

## Resource_Share.py
 #
 # Share hardware resources with lock files.
 #

import sys
import argparse
import os
from pathlib import Path
import time
import json

defaultTimeout=60

# Setup the command line description text
descText = """
Share hardware resources with lock files.

This tool creates lock files and prevents resource contention. Calling this will block
until the resource can be locked or times out waiting.

return values:
0: Success
1: Timeout waiting for lock to release
2: Trying to unlock a file that doesn't exits
"""

# Parse the command line arguments
parser = argparse.ArgumentParser(description=descText, formatter_class=argparse.RawTextHelpFormatter)


parser.add_argument('--timeout', '-t', default=defaultTimeout, help='Timeout before returning in seconds')
parser.add_argument('--lock', '-l', action='store_true', help='Lock the file, otherwise unlock the file')
parser.add_argument('-b','--board', action='append', help='Name of board to lock per boards_config.json', required=True)

args = parser.parse_args()

#parse json file to check if lockfile for board exists
LOCK_FILE_DIR="/home/btm-ci/Workspace/Resource_Share/Locks/"
BOARDS_FILE="/home/btm-ci/Workspace/Resource_Share/boards_config.json"
LOCK_FILE=""

def boardsAreLocked(locks):
    for lockfile in locks:
        if os.path.exists(lockfile):
            return True
    return False




boards = set(args.board)
lockfiles = []
successfulLocks = {}

#get a list of lockfiles 
for board in boards:
    
    BOARD=""
    try:
        # resolve board from a path if possible (legacy)
        BOARD= Path(board).resolve().stem
        LOCK_FILE = json.load(open(BOARDS_FILE))[BOARD]['lockfile']
    except Exception as e:
        print(f"!!!!! Bad BOARD name:[{BOARD}] !!!!!")


    lockfiles.append(LOCK_FILE_DIR+LOCK_FILE)


if(args.lock):
    
    print(f'Attempting to lock all boards {lockfiles}')
    toSeconds = int(args.timeout)
    
    
    while(toSeconds):

        if(boardsAreLocked(lockfiles)):
            time.sleep(1)
            toSeconds = toSeconds - 1
            if(toSeconds == 0):
                print("Timed out waiting for lockFile to be released")
                sys.exit(1)
        else:
            toSeconds = 0
    
    for lockfile in lockfiles:
        
        # Create the lock file
        Path(lockfile).touch()
        # Open the file
        lock = open(lockfile, 'r+')
        # Write the PID to the file
        lock.truncate(0)
        lock.write(str(os.getpid())+"\n")
        # Close the file
        lock.close()

    
else:
    for lockfile in lockfiles:
        # Test to see if the file exists
        if(not os.path.exists(lockfile)):
            print("Lock file does not exits")
        else:
            print(f"Unlocking {lockfile}")
            if(os.path.exists(lockfile)):
                os.remove(lockfile)
        

    
sys.exit(0)
