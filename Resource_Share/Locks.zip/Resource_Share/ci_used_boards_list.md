# List boards used in all the CI tests

| test              | lock file name  | json ID          | SN |   |
|-------------------|-----------------|------------------|----|---|
| timing            | max32655_0.txt  |                  |    |   |
| timing            | max32655_1.txt  |                  |    |   |
| timing            | max32665_13.txt |                  |    |   |
| timing            | max32690_w1.txt |                  |    |   |
| PER               | rf_switch.txt   |                  |    |   |
|                   | rs_fsl.txt      |                  |    |   |
|                   | nrf_0.txt       |                  |    |   |
|                   | max32655_2.txt  | max32655_board_2 | #2 |   |
|                   | max32665_0.txt  |                  |    |   |
|                   | max32665_1.txt  |                  |    |   |
|                   | max32665_w3.txt |                  |    |   |
|                   | max32665_w4.txt |                  |    |   |
|                   | max32690_w2.txt |                  |    |   |
| BLE_Examples_Test | max32655_0.txt  |                  |    |   |
|                   | max32655_1.txt  |                  |    |   |
|                   | max32665_13.txt |                  |    |   |
|                   | max32690_w1.txt |                  |    |   |
|                   | max32690_a5.txt |                  |    |   |
